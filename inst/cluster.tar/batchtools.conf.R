cluster.functions <- makeClusterFunctionsSlurm(
                    template = "/home/clz4002/batchtools.slurm.tmpl"
)
